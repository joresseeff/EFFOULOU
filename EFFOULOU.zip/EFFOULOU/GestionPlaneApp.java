import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Classe représentant un avion
class Plane {
    private String immatriculation;
    private String modele;
    private int capacite;
    private int vitesseMax;
    private int altitudeMax;
    private int anneeConstruction;

    public Plane(String immatriculation, String modele, int capacite, int vitesseMax, int altitudeMax, int anneeConstruction) {
        this.immatriculation = immatriculation;
        this.modele = modele;
        this.capacite = capacite;
        this.vitesseMax = vitesseMax;
        this.altitudeMax = altitudeMax;
        this.anneeConstruction = anneeConstruction;
    }

    public String getImmatriculation() {
        return immatriculation;
    }

    public String getModele() {
        return modele;
    }

    public int getCapacite() {
        return capacite;
    }

    public int getVitesseMax() {
        return vitesseMax;
    }

    public int getAltitudeMax() {
        return altitudeMax;
    }

    public int getAnneeConstruction() {
        return anneeConstruction;
    }

    @Override
    public String toString() {
        return immatriculation + "," + modele + "," + capacite + "," + vitesseMax + "," + altitudeMax + "," + anneeConstruction;
    }

    public static Plane fromString(String line) {
        String[] parts = line.split(",");
        if (parts.length < 6) {
            throw new IllegalArgumentException("Format de données invalide : " + line);
        }
        return new Plane(
                parts[0].trim(),
                parts[1].trim(),
                Integer.parseInt(parts[2].trim()),
                Integer.parseInt(parts[3].trim()),
                Integer.parseInt(parts[4].trim()),
                Integer.parseInt(parts[5].trim())
        );
    }
}

// Classe pour gérer les opérations sur le fichier
class FileHandler {
    public static void savePlanes(List<Plane> planes, String filename) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Plane plane : planes) {
                writer.write(plane.toString());
                writer.newLine();
            }
        }
    }

    public static List<Plane> loadPlanes(String filename) throws IOException {
        List<Plane> planes = new ArrayList<>();
        File file = new File(filename);
        if (!file.exists()) {
            return planes;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    try {
                        planes.add(Plane.fromString(line));
                    } catch (IllegalArgumentException e) {
                        System.err.println("Erreur de format pour la ligne : " + line);
                    }
                }
            }
        }
        return planes;
    }
}

// Application principale
public class GestionPlaneApp {
    private List<Plane> planes;
    private DefaultTableModel tableModel;
    private JTable table;
    private static final String FILENAME = "planes.txt";

    public GestionPlaneApp() {
        planes = new ArrayList<>();
        try {
            planes = FileHandler.loadPlanes(FILENAME);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Erreur de lecture du fichier !");
            e.printStackTrace();
        }

        // Configuration de l'interface Swing
        JFrame frame = new JFrame("Gestion des Avions");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        JPanel panel = new JPanel(new BorderLayout());

        // Tableau pour afficher les avions
        tableModel = new DefaultTableModel(new String[]{"Immatriculation", "Modèle", "Capacité", "Vitesse Max", "Altitude Max", "Année Construction"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Boutons d'action
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Ajouter");
        JButton deleteButton = new JButton("Supprimer");
        JButton modifyButton = new JButton("Modifier");
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(modifyButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Chargement initial des données
        refreshTable();

        // Gestion du bouton Ajouter
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField immatriculationField = new JTextField();
                JTextField modeleField = new JTextField();
                JTextField capaciteField = new JTextField();
                JTextField vitesseMaxField = new JTextField();
                JTextField altitudeMaxField = new JTextField();
                JTextField anneeConstructionField = new JTextField();

                Object[] fields = {
                        "Immatriculation :", immatriculationField,
                        "Modèle :", modeleField,
                        "Capacité :", capaciteField,
                        "Vitesse Max (km/h) :", vitesseMaxField,
                        "Altitude Max (m) :", altitudeMaxField,
                        "Année de Construction :", anneeConstructionField
                };

                int option = JOptionPane.showConfirmDialog(frame, fields, "Ajouter un avion", JOptionPane.OK_CANCEL_OPTION);
                if (option == JOptionPane.OK_OPTION) {
                    try {
                        String immatriculation = immatriculationField.getText().trim();
                        String modele = modeleField.getText().trim();
                        int capacite = Integer.parseInt(capaciteField.getText().trim());
                        int vitesseMax = Integer.parseInt(vitesseMaxField.getText().trim());
                        int altitudeMax = Integer.parseInt(altitudeMaxField.getText().trim());
                        int anneeConstruction = Integer.parseInt(anneeConstructionField.getText().trim());

                        Plane plane = new Plane(immatriculation, modele, capacite, vitesseMax, altitudeMax, anneeConstruction);
                        planes.add(plane);
                        refreshTable();
                        saveData();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Veuillez entrer des valeurs valides.");
                    }
                }
            }
        });

        // Gestion du bouton Modifier
        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    Plane planeToModify = planes.get(selectedRow);
                    modifyPlane(planeToModify, selectedRow);
                } else {
                    JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un avion à modifier.");
                }
            }
        });

        // Gestion du bouton Supprimer
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    planes.remove(selectedRow);
                    refreshTable();
                    saveData();
                } else {
                    JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un avion à supprimer.");
                }
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Plane plane : planes) {
            tableModel.addRow(new Object[]{
                    plane.getImmatriculation(),
                    plane.getModele(),
                    plane.getCapacite(),
                    plane.getVitesseMax(),
                    plane.getAltitudeMax(),
                    plane.getAnneeConstruction()
            });
        }
    }

    private void saveData() {
        try {
            FileHandler.savePlanes(planes, FILENAME);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Erreur de sauvegarde des données !");
            e.printStackTrace();
        }
    }

    private void modifyPlane(Plane planeToModify, int rowIndex) {
        JTextField immatriculationField = new JTextField(planeToModify.getImmatriculation());
        JTextField modeleField = new JTextField(planeToModify.getModele());
        JTextField capaciteField = new JTextField(String.valueOf(planeToModify.getCapacite()));
        JTextField vitesseMaxField = new JTextField(String.valueOf(planeToModify.getVitesseMax()));
        JTextField altitudeMaxField = new JTextField(String.valueOf(planeToModify.getAltitudeMax()));
        JTextField anneeConstructionField = new JTextField(String.valueOf(planeToModify.getAnneeConstruction()));

        Object[] fields = {
                "Immatriculation :", immatriculationField,
                "Modèle :", modeleField,
                "Capacité :", capaciteField,
                "Vitesse Max (km/h) :", vitesseMaxField,
                "Altitude Max (m) :", altitudeMaxField,
                "Année de Construction :", anneeConstructionField
        };

        int option = JOptionPane.showConfirmDialog(null, fields, "Modifier un avion", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String immatriculation = immatriculationField.getText().trim();
                String modele = modeleField.getText().trim();
                int capacite = Integer.parseInt(capaciteField.getText().trim());
                int vitesseMax = Integer.parseInt(vitesseMaxField.getText().trim());
                int altitudeMax = Integer.parseInt(altitudeMaxField.getText().trim());
                int anneeConstruction = Integer.parseInt(anneeConstructionField.getText().trim());

                Plane modifiedPlane = new Plane(immatriculation, modele, capacite, vitesseMax, altitudeMax, anneeConstruction);
                planes.set(rowIndex, modifiedPlane); // Replace the old plane with the modified one
                refreshTable();
                saveData();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Veuillez entrer des valeurs valides.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GestionPlaneApp::new);
    }
}


